
public class Canguru extends Mamifero {
	@Override
	public void locomover() {
		// TODO Auto-generated method stub
		System.out.println("Saltando!!"); //aqui subrepoe o metodo de mamifero.
	}
}
